Animals
=======

*Created by Cesiyi and KsIsCute*

Examples:
---------

.. code:: py

   import animals # Importing the library
   from animals import animal # Import main class
   picture = animal.picture("dog") # Get a dog picture
   print(picture) # Print the link to the required picture

======= ==================
Version Support
======= ==================
>3.8.X  ✅
3.0+    ✅
2.7+    ❎
>2.6.X  ❎
======= ==================
