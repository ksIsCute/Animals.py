Animals
=======

*Created by Cesiyi and KsIsCute*

Examples:
---------

.. code:: py

   import animalpy # Importing the library
   from animalpy import animals # Import main class
   picture = animals.picture("dog") # Get a dog picture
   print(picture) # Print the link to the required picture

======= ==================
Version Support
======= ==================
>3.8.X  ✅
3.0+    ✅
2.7+    ❎
>2.6.X  ❎
======= ==================
